#pragma once
#include "stdafx.h"

class Object
{
public:

	Object(std::string);

	void Update();
	std::vector<sf::Vector2f> GetPoints();

	sf::Transform matrix;

	sf::VertexArray *ptr;

	unsigned int ID;

	bool checked = false;

};