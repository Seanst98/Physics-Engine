#pragma once
#include "stdafx.h"
#include "Object.h"
#include "ResourceManager.h"
#include "Game.h"

Object::Object(std::string name)
{
	//ptr = ResourceManager::Get(name);
}

void Object::Update()
{

	/*sf::Transform transform;

	transform.translate(50*ET,50*ET);

	matrix.combine(transform);*/
}

std::vector<sf::Vector2f> Object::GetPoints()
{
	std::vector<sf::Vector2f> points;

	points = Game::resManager.GetPoints("triangle");

	return points;
}