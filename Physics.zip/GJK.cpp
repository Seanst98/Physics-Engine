#include "stdafx.h"
#include "GJK.h"
#include "Map.h"
#include "Game.h"

GJK::GJK()
{

}

bool GJK::Check(Object* O1, Object* O2)
{
	sf::Vector2f d(1, 0);

	simplex.Add(support(O1, O2, d));

	d.x = -d.x;
	d.y = -d.y;

	while (true)
	{
		simplex.Add(support(O1, O2, d));

		sf::VertexArray s;
		s.setPrimitiveType(sf::Triangles);

		for (int i = 0; i < simplex.points.size(); i++)
		{
			sf::Vertex temp;

			if (i == 0) { temp.color = sf::Color::Red; }
			if (i == 1) { temp.color = sf::Color::Blue; }
			if (i == 2) { temp.color = sf::Color::Green; }
			temp.position.x = simplex.points[i].x;
			temp.position.y = simplex.points[i].y;

			s.append(temp);

		}


		//std::cout << simplex.points.size() << std::endl;
		Game::mainWindow.draw(s);

		if (Dot(simplex.getLast(), d) <= 0.0)
		{
			return false;
		}
		else
		{
			if (containsOrigin(d))
			{
				return true;
			}


		}

	}
}

bool GJK::containsOrigin(sf::Vector2f& d)
{
	sf::Vector2f A = simplex.getLast();

	sf::Vector2f AO = -A;

	if (simplex.points.size() == 3)
	{

		sf::Vector2f B = simplex.points[0];
		sf::Vector2f C = simplex.points[1];

		sf::Vector2f AB = B - A;
		sf::Vector2f AC = C - A;

		sf::Vector2f ABPerp = tripleProduct(AC, AB, AB);
		sf::Vector2f ACPerp = tripleProduct(AB, AC, AC);

		if ((Dot(ABPerp, AO)) > 0)
		{
			simplex.Remove(1);
			d = ABPerp;

			d = Normalise(d);

		}
		else
		{
			if ((Dot(ACPerp, AO)) > 0)
			{
				simplex.Remove(0);
				d = ACPerp;

				d = Normalise(d);
			}
			else
			{
				//std::cout << "R5" << std::endl;
				return true;
			}
		}

	}
	else
	{
		sf::Vector2f B = simplex.points[0];
		sf::Vector2f AB = B - A;

		sf::Vector2f ABPerp = tripleProduct(AB, AO, AB);

		d = ABPerp;

		d = Normalise(d);
	}

	return false;

}


sf::Vector2f GJK::tripleProduct(sf::Vector2f A, sf::Vector2f B, sf::Vector2f C)
{
	//(A x B) x C
	//B(C.dot(A)) � A(C.dot(B))

	sf::Vector2f temp;
	sf::Vector2f temp2;
	float dot1;
	float dot2;

	dot1 = Dot(A, C);
	dot2 = Dot(C, B);

	temp.x = dot1 * B.x;
	temp.y = dot1 * B.y;

	temp2.x = dot2 * A.x;
	temp2.y = dot2 * A.y;

	return (temp - temp2);


}

sf::Vector2f GJK::Normalise(sf::Vector2f d)
{
	double magnitude = (d.x * d.x) + (d.y*d.y);
	magnitude = std::sqrt(magnitude);

	d.x = d.x / magnitude;
	d.y = d.y / magnitude;

	return d;
}

float GJK::Dot(sf::Vector2f A, sf::Vector2f B)
{
	return (A.x * B.x) + (A.y * B.y);
}

sf::Vector2f GJK::support(Object* shape1, Object* shape2, sf::Vector2f d) {

	sf::Vector2f p1 = GetFarthest(shape1, d);

	sf::Vector2f p2 = GetFarthest(shape2, -d);

	sf::Vector2f p3 = p1-p2;

	return p3;

}


sf::Vector2f GJK::GetFarthest(Object* shape, sf::Vector2f d)
{
	std::vector<sf::Vector2f> points = shape->GetPoints();
	sf::Vector2f farthest;
	float farDistance = -100000000;

	for (int i = 0; i < shape->ptr->getVertexCount(); i++)
	{
		float temp = Dot(d, shape->matrix.transformPoint(points[i]));

		if (temp > farDistance)
		{
			farDistance = temp;
			farthest = shape->matrix.transformPoint(points[i]);
		}
	}

	return farthest;
}
